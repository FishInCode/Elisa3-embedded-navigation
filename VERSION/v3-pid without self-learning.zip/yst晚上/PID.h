#ifndef __PID_H__
#define __PID_H__

extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char InitSpeedA,InitSpeedB;
extern unsigned char idata MultiChannelAdcBuffer[9];
extern unsigned int GetTrackInfo();

extern unsigned char idata MotorAfunction,MotorBfunction,MotorCfunction;
extern unsigned int GetTrackInfo();
extern unsigned char InitSpeedA,InitSpeedB;
extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char data FlagOf10ms;
extern unsigned int data UpTo10miniterTimerPer10ms;
extern float Kp,Pout,Iout,Dout;
extern unsigned int Ti,Td;
void InitPID(void);
void TraceTheBlackLine(void);
void SHOWDKK();
unsigned int GetTrackInfo();

#endif