#ifndef __TIMER_H__
#define __TIMER_H__

extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char InitSpeedA,InitSpeedB;
extern unsigned char idata MultiChannelAdcBuffer[9];
extern unsigned int GetTrackInfo();

#endif
