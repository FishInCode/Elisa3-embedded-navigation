#include "InfraredTrack.h"
#include "stc8a8kxxd4.h"
#include "oled.h"

#define err 255
#define bal 0

unsigned char bdata High_Track_bit = 0;
unsigned char bdata Low_Track_bit = 0;

unsigned char xdata Track_info[64] =
{
	bal, 33, 25, 30,  2,err,  4, 27,     //0~7
	253,err,err, 12,bal,err, 16, 24,     //8~15
	230,err,err,err,err,err,err,err,    //16~23
	251,err,err,err,235,err,err, 15,    //24~31
	222,err,err,err,err,err,err,err,    //32~39
	err,err,err,err,err,err,err,err,    //40~47
	225,err,err,err,243,err,err,err,    //48~55
	228,err,err,err,226,err,240,bal     //56~63
};

sbit Track_bit0 = Low_Track_bit ^ 0;
sbit Track_bit1 = Low_Track_bit ^ 1;
sbit Track_bit2 = Low_Track_bit ^ 2;
sbit Track_bit3 = Low_Track_bit ^ 3;
sbit Track_bit4 = Low_Track_bit ^ 4;
sbit Track_bit5 = Low_Track_bit ^ 5;
sbit Track_bit6 = Low_Track_bit ^ 6;
sbit Track_bit7 = Low_Track_bit ^ 7;
sbit Track_bit8 = High_Track_bit ^ 0;

unsigned int GetTrackInfo()
{
	Track_bit0 &= !(MultiChannelAdcBuffer[8] <= 60);
	Track_bit0 |=  (MultiChannelAdcBuffer[8] >= 200);
	
	Track_bit1 &= !(MultiChannelAdcBuffer[7] <= 60);
	Track_bit1 |=  (MultiChannelAdcBuffer[7] >= 200);

	Track_bit2 &= !(MultiChannelAdcBuffer[6] <= 60);
	Track_bit2 |=  (MultiChannelAdcBuffer[6] >= 200);
	
	Track_bit3 &= !(MultiChannelAdcBuffer[5] <= 60);
	Track_bit3 |=  (MultiChannelAdcBuffer[5] >= 200);
	
	Track_bit4 &= !(MultiChannelAdcBuffer[4] <= 60);
	Track_bit4 |=  (MultiChannelAdcBuffer[4] >= 200);
	
	Track_bit5 &= !(MultiChannelAdcBuffer[3] <= 60);
	Track_bit5 |=  (MultiChannelAdcBuffer[3] >= 200);
	
	Track_bit6 &= !(MultiChannelAdcBuffer[2] <= 60);
	Track_bit6 |=  (MultiChannelAdcBuffer[2] >= 200);
	
	Track_bit7 &= !(MultiChannelAdcBuffer[1] <= 60);
	Track_bit7 |=  (MultiChannelAdcBuffer[1] >= 200);
	
	Track_bit8 &= !(MultiChannelAdcBuffer[0] <= 60);
	Track_bit8 |=  (MultiChannelAdcBuffer[0] >= 200);
	
	return (High_Track_bit << 8) | Low_Track_bit;
}

