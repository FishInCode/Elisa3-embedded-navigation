#include "PID.h"
#include "stc8a8kxxd4.h"
#include <intrins.h>
#include <math.h>
#include "oled.h"

#define	uchar unsigned char
#define	uint unsigned int

#define err 100
#define	ErrorArrLenth 512
#define T 1		//����ʱ��(����ʱ��):1ms

char xdata TrackInfoArr[7168];	//7*1024=7168
uint data TrackInfoArrPointer;
//uchar data StartStopLine;
//uchar data CoverOnTheStartStopLine;
uint data ErrorArrPointer;
char xdata ErrorArr[ErrorArrLenth];
int SumOfErrors = 0;	//�����ۼӺ�(��������Զ����һ�����)

unsigned char bdata High_Track_bit = 0;
unsigned char bdata Low_Track_bit = 0;

char xdata Track_info[512] =
{
	100,45,20,40,7,100,10,30,2,100,100,       100,3,100,15,100,10,100,100,100,100,       //0-20
	100,100,100,1,100,100,100,5,100,100,      100,-2,100,100,100,100,100,100,100,100,    //21-40
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,0,100,100,100,100,     //41-60
	100,100,100,-7,100,100,100,100,100,100,   100,100,100,100,100,100,100,100,100,100,   //61-80
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,-3,100,100,100,100,    //81-100
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //101-120
	100,100,100,100,100,100,100,-20,100,100,  100,100,100,100,100,100,100,100,100,100,   //121-140
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //141-160
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //161-180
	100,100,100,100,100,100,100,100,100,100,  100,-10,100,100,100,100,100,100,100,100,   //181-200
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //201-220
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //221-240
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,-45,100,100,100,100,   //241-260
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //261-280
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //281-300
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //301-320
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //321-340
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //341-360
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //361-380
	100,100,100,-40,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //381-400
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //401-420
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //421-440
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //441-460
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //461-480
	100,100,100,100,100,100,100,100,100,100,  100,100,100,100,100,100,100,100,100,100,   //481-500
	100,100,100,100,100,100,100,100,100,100,  100                                        //501-511
	
};

sbit Track_bit0 = Low_Track_bit ^ 0;
sbit Track_bit1 = Low_Track_bit ^ 1;
sbit Track_bit2 = Low_Track_bit ^ 2;
sbit Track_bit3 = Low_Track_bit ^ 3;
sbit Track_bit4 = Low_Track_bit ^ 4;
sbit Track_bit5 = Low_Track_bit ^ 5;
sbit Track_bit6 = Low_Track_bit ^ 6;
sbit Track_bit7 = Low_Track_bit ^ 7;
sbit Track_bit8 = High_Track_bit ^ 0;

unsigned int GetTrackInfo()
{
	Track_bit0 &= !(MultiChannelAdcBuffer[8] <= 60);
	Track_bit0 |=  (MultiChannelAdcBuffer[8] >= 200);
	
	Track_bit1 &= !(MultiChannelAdcBuffer[7] <= 60);
	Track_bit1 |=  (MultiChannelAdcBuffer[7] >= 200);

	Track_bit2 &= !(MultiChannelAdcBuffer[6] <= 60);
	Track_bit2 |=  (MultiChannelAdcBuffer[6] >= 200);
	
	Track_bit3 &= !(MultiChannelAdcBuffer[5] <= 60);
	Track_bit3 |=  (MultiChannelAdcBuffer[5] >= 200);
	
	Track_bit4 &= !(MultiChannelAdcBuffer[4] <= 60);
	Track_bit4 |=  (MultiChannelAdcBuffer[4] >= 200);
	
	Track_bit5 &= !(MultiChannelAdcBuffer[3] <= 60);
	Track_bit5 |=  (MultiChannelAdcBuffer[3] >= 200);
	
	Track_bit6 &= !(MultiChannelAdcBuffer[2] <= 60);
	Track_bit6 |=  (MultiChannelAdcBuffer[2] >= 200);
	
	Track_bit7 &= !(MultiChannelAdcBuffer[1] <= 60);
	Track_bit7 |=  (MultiChannelAdcBuffer[1] >= 200);
	
	Track_bit8 &= !(MultiChannelAdcBuffer[0] <= 60);
	Track_bit8 |=  (MultiChannelAdcBuffer[0] >= 200);
	
	return (High_Track_bit << 8) | Low_Track_bit;
}

void SHOWDKK()
{
	OledShowUnsignedInteger(56,6,Track_bit8,16);
	OledShowUnsignedInteger(64,6,Track_bit7,16);
	OledShowUnsignedInteger(72,6,Track_bit6,16);
	OledShowUnsignedInteger(80,6,Track_bit5,16);
	OledShowUnsignedInteger(88,6,Track_bit4,16);
	OledShowUnsignedInteger(96,6,Track_bit3,16);
	OledShowUnsignedInteger(104,6,Track_bit2,16);
	OledShowUnsignedInteger(112,6,Track_bit1,16);
	OledShowUnsignedInteger(120,6,Track_bit0,16);

//	OledShowUnsignedInteger(56,6,Track_bit0,16);
//	OledShowUnsignedInteger(64,6,Track_bit5,16);
//	OledShowUnsignedInteger(72,6,Track_bit1,16);
//	OledShowUnsignedInteger(80,6,Track_bit6,16);
//	OledShowUnsignedInteger(88,6,Track_bit2,16);
//	OledShowUnsignedInteger(96,6,Track_bit7,16);
//	OledShowUnsignedInteger(104,6,Track_bit3,16);
//	OledShowUnsignedInteger(112,6,Track_bit8,16);
//	OledShowUnsignedInteger(120,6,Track_bit4,16);
}

void SaveErrorAndSumIt(void)		//�������ֵ���������ۼӺ�
	{
	uchar TrackInfo;
//	uint intReg;

	TrackInfo = GetTrackInfo();
	
	TrackInfoArr[TrackInfoArrPointer] = TrackInfo;	//����С��λ����Ϣ
	TrackInfoArrPointer ++;
	if(TrackInfoArrPointer > 7167) {TrackInfoArrPointer = 0;}	//0~7*1024-1
	
//	if( TrackInfo == 100)	{return;}	//С��λ�ñ����쳣������������Ч
//	
//	if( TrackInfo == 99)	//��ͣ��
//		{
//		StartStopLine = 1;
//		CoverOnTheStartStopLine ++;		//ͳ������ͣ���ϴ����������Ĵ���
//		return;
//		}	
//		
//	if( StartStopLine )	//Խ����ͣ�ߺ�ĵ�һ����Чλ����
//		{
//		StartStopLine = 0;
//		MotorAfunction = 3; MotorBfunction = 3;
//		
//		OledShowUnsignedInteger(80,0,UpTo10miniterTimerPer10ms,16);	//��ʾ����һȦ��ʱ�䣬��λ��10ms
//		OledShowUnsignedInteger(96,2,CoverOnTheStartStopLine,16);	//��ʾԽ����ͣ�߾�����ʱ�䣬��λ��10ms
//			
//		FlagOf10ms = 0;				
//		while(FlagOf10ms < 250)		//ͣ��2��
//			{
//			_nop_();
//			OledShowUnsignedInteger(80,2,FlagOf10ms/10,16);
//				
////			if(AdcFinished == 1)
////				{
////				AdcFinished = 0;
////				floatReg = AdcValue;
////				floatReg *= 0.003662109; //5/4096*3
////				OledShowFloatWithoutPole(80,6,floatReg,5);	
////				}
//			}
//		OledClearUnsignedInteger(80,2,FlagOf10ms/100,16);	//�����һ����ʾ����Ϣ
//		OledClearUnsignedInteger(96,2,CoverOnTheStartStopLine,16);	
//		OledClearUnsignedInteger(80,0,UpTo10miniterTimerPer10ms,16);
//		CoverOnTheStartStopLine = 0;
//		UpTo10miniterTimerPer10ms = 0;
//			
//		MotorAfunction = 0; MotorBfunction = 0;
//		}
//	
////���������СȦʱ���Ҳ��������Ҷȴ�����ʱ����ֹС��λ�ñ���ͻ��
////	if( abs(charReg - ErrorBuffer[ErrorBufferPointer]) > 100)	{return;}
	
	ErrorArrPointer ++;
	ErrorArrPointer &= (ErrorArrLenth-1);	
	ErrorArr[ErrorArrPointer] = TrackInfo;

	SumOfErrors += TrackInfo;
	
	}



void InitPID(void)		//PID ��ʼ��
	{
		
	uint intReg;
	PulseWidthOfMotorA=0; PulseWidthOfMotorB=0;
	Kp = 0.1;		//����ϵ��
	Td = 50;		//΢��ʱ��
	Ti = Td * 4;	//����ʱ��

	for(intReg=0;intReg<ErrorArrLenth;intReg++)
		{
			ErrorArr[intReg] = 0;
		}
//	CoverOnTheStartStopLine = 0;
	TrackInfoArrPointer = 0;
	ErrorArrPointer = 0;
	SumOfErrors = 0;
		
	}
	
void TraceTheBlackLine(void)
	{
		
//	FlagOf10ms = 0;
//	while(FlagOf10ms < 20)	;

//	MotorAfunction = 0; MotorBfunction = 0;
		
	while(1)
		{
			SaveErrorAndSumIt();	//�������ֵ���������ۼӺ�
							
			Pout = Kp * ErrorArr[ErrorArrPointer];	//���� Kp * Ek					
			Iout = SumOfErrors;
			Iout /= (ErrorArrLenth/64);	
			Iout *= Kp;Iout /= Ti;		//����
			Dout = ErrorArr[ErrorArrPointer]-ErrorArr[ErrorArrPointer-1];//΢��
			Dout *= Td; 
			Dout *= Kp;	
				
			PulseWidthOfMotorA = InitSpeedA + Pout + Iout + Dout;	//CCAP1ռ�ձ�=(PulseWidthOfPWM + PidOut)/128
			PulseWidthOfMotorB = InitSpeedB - Pout - Iout - Dout;	//CCAP0ռ�ձ�=(PulseWidthOfPWM - PidOut)/128
		}
			
//		_nop_();
//		if(F2keyShortPress)
//			{
//			F2keyShortPress=0;
//				
//			PulseWidthOfMotorA = InitSpeedA;	//CCAP1ռ�ձ�=(PulseWidthOfPWM + PidOut)/128
//			PulseWidthOfMotorB = InitSpeedB;
//			MotorAfunction = 3; MotorBfunction = 3;
//			
//			break;
//			}

//		}

	}