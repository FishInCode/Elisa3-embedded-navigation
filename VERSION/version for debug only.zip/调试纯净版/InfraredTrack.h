#ifndef __TIMER_H__
#define __TIMER_H__

extern void Track();

#endif
