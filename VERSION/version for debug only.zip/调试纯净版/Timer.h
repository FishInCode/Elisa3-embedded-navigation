
#ifndef __TIMER_H__
#define __TIMER_H__


#include "stc8a8kxxd4.h"
#include <intrins.h>


#define FOSC 18432000L
//#define FOSC 22118400L
//#define FOSC 33177600L
//#define FOSC 36864000L
//#define FOSC 44236800L

#define  timer0InterruptFrequency 10000
#define  timer1InterruptFrequency 100
#define  timer2InterruptFrequency 1000
#define  timer3InterruptFrequency 1000
#define  timer4InterruptFrequency 1000




extern void initialTimer0_4(void);

#endif

