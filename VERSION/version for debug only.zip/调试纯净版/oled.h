//  �� �� ��   : oled.h
//  �� �� ��   : v1.0
//  ��    ��   : cl
//  �������   : 2019-0518


#ifndef __OLED_H__
#define __OLED_H__


#define  u8 unsigned char 
#define  u16 unsigned int
#define  u32 unsigned long
#define OLED_CMD  0	//д����
#define OLED_DATA 1	//д����
#define OLED_MODE 0
#define SIZE 16
#define XLevelL		0x02
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64

#define OLED_SCLK_Clr() OLED_SCL=0;_nop_();;_nop_();_nop_();_nop_();_nop_()
#define OLED_SCLK_Set() OLED_SCL=1;_nop_();_nop_();_nop_();_nop_();_nop_()

#define OLED_SDIN_Clr() OLED_SDIN=0;_nop_();_nop_();_nop_();_nop_();_nop_()
#define OLED_SDIN_Set() OLED_SDIN=1;_nop_();_nop_();_nop_();_nop_();_nop_()

sbit OLED_SCL  = P5^5;		//ʱ�� D0��CLK��
sbit OLED_SDIN = P5^4;		//���� D1��SDA��

extern void delay_ms(unsigned int ms);
extern void Delay_50ms(unsigned int Del_50ms);
extern void Delay_1ms(unsigned int Del_1ms);
//OLED��غ���
extern void OLED_WR_Byte(unsigned dat,unsigned cmd);  
extern void OLED_Display_On(void);
extern void OLED_Display_Off(void);	   							   		    
extern void OLED_Init(void);
extern void OLED_Clear(void);
extern void OLED_DrawPoint(u8 x,u8 y,u8 t);
extern void OLED_Fill(u8 x1,u8 y1,u8 x2,u8 y2,u8 dot);
extern void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 Char_Size);
extern void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size);
extern void OLED_ShowString(u8 x,u8 y, u8 *p,u8 Char_Size);	

extern void OLED_Set_Pos(unsigned char x, unsigned char y);
extern void OLED_ShowCHinese(u8 x,u8 y,u8 no);
extern void OLED_DrawBMP(unsigned char x0, unsigned char y0,unsigned char x1, unsigned char y1,unsigned char BMP[]);
extern void fill_picture(unsigned char fill_Data);
extern void Picture();
extern void IIC_Start();
extern void IIC_Stop();
extern void Write_IIC_Command(unsigned char IIC_Command);
extern void Write_IIC_Data(unsigned char IIC_Data);
extern void Write_IIC_Byte(unsigned char IIC_Byte);
extern void IIC_Wait_Ack();
extern void OLED_ShowArrow(u8 x,u8 y,u8 no);
extern void OLED_ShowSignedNum(u8 x,u8 y,long Num,u8 Len,u8 Size3);
extern void OLED_ShowFloatNum(u8 x,u8 y,float Num,u8 Len,u8 Size4);

//extern void OLED_ShowNum0(u8 x,u8 y,long Num,u8 Len,u8 Size5);
extern void OLED_ShowNum0(u8 x,u8 y,unsigned long Num,u8 Len,u8 Size5);

extern const unsigned char code F6x8[][6];
extern const unsigned char code F8x16[];
extern const unsigned char code Hzk[][32];
extern const unsigned char code BMP1[];
extern const unsigned char code BMP2[];

#endif

