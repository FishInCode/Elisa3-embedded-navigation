#include "InfraredTrack.h"
#include "stc8a8kxxd4.h"

char idata Track_info[64];
//{






//};

extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char data InitSpeedA,InitSpeedB;
extern unsigned char data ADCdata[7];
unsigned char bdata Track_bit = 0;

sbit Track_bit0 = Track_bit ^ 0;
sbit Track_bit1 = Track_bit ^ 1;
sbit Track_bit2 = Track_bit ^ 2;
sbit Track_bit3 = Track_bit ^ 3;
sbit Track_bit4 = Track_bit ^ 4;
sbit Track_bit5 = Track_bit ^ 5;

unsigned char GetTrackInfo()
{
	if(ADCdata[0] <= 16)		{Track_bit5 = 0;}
	else if(ADCdata[0] >= 32)   {Track_bit5 = 1;}
	
	if(ADCdata[1] <= 16)		{Track_bit4 = 0;}
	else if(ADCdata[1] >= 32)	{Track_bit4 = 1;}
	
	if(ADCdata[2] <= 16)		{Track_bit3 = 0;}
	else if(ADCdata[2] >= 32)	{Track_bit3 = 1;}
	
	if(ADCdata[3] <= 16)		{Track_bit2 = 0;}
	else if(ADCdata[3] >= 32)	{Track_bit2 = 1;}
	
	if(ADCdata[4] <= 16)		{Track_bit1 = 0;}
	else if(ADCdata[4] >= 32)	{Track_bit1 = 1;}
	
	if(ADCdata[5] <= 16)		{Track_bit0 = 0;}
	else if(ADCdata[5] >= 32)	{Track_bit0 = 1;}
	
	return Track_bit;
}

void Track()
{
	GetTrackInfo();
	if(Track_info[Track_bit] == 0) {PulseWidthOfMotorA = InitSpeedA;PulseWidthOfMotorB = InitSpeedB;}
	if(Track_info[Track_bit] > 0) {PulseWidthOfMotorA += Track_info[Track_bit];}
	if(Track_info[Track_bit] < 0) {PulseWidthOfMotorA += Track_info[Track_bit];}
}
