#ifndef __TIMER_H__
#define __TIMER_H__
void Track();

//extern unsigned char ADCBlackInfo[9],ADCWhiteInfo[9];
extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char InitSpeedA,InitSpeedB;
extern unsigned char idata MultiChannelAdcBuffer[9];
#endif
