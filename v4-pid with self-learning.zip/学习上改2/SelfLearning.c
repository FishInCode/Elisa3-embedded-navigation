#include "stc8a8kxxd4.h"
#include <intrins.h>
#include "SelfLearning.h"
#include "oled.h"

#define SENSOR_COUNT 9
#define SAMPLE_SIZE 255    
#define TRIM_COUNT 50      
#define THRESHOLD_RANGE 20
#define BLACK_THRESHOLD 150 
#define WHITE_THRESHOLD 50   

struct SensorCal {
    unsigned char black_samples[SAMPLE_SIZE];
    unsigned char white_samples[SAMPLE_SIZE];
    unsigned char black_center;
    unsigned char white_center;
    unsigned char black_min, black_max;
    unsigned char white_min, white_max;
    unsigned char sample_counts[2]; //0:black 1:white
};

struct SensorCal xdata sensors[SENSOR_COUNT];

void init_sensors()
{
    unsigned char i, j;
    for (i = 0; i < SENSOR_COUNT; i++) {
        sensors[i].sample_counts[0] = 0;
        sensors[i].sample_counts[1] = 0;
        for (j = 0; j < SAMPLE_SIZE; j++) {
            sensors[i].black_samples[j] = 0;
            sensors[i].white_samples[j] = 0;
        }
    }
}

void read_all_sensors(unsigned char* values)
{
    unsigned char i;
    for (i = 0; i < SENSOR_COUNT; i++)
        values[i] = MultiChannelAdcBuffer[i];
}

void insert_sort(unsigned char arr[], unsigned char n)
{
    unsigned char i, j;
    for (i = 1; i < n; i++)
	{
        unsigned char temp = arr[i];
        j = i;
        while (j > 0 && arr[j - 1] > temp)
		{
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = temp;
    }
}

unsigned char calculate_average(unsigned char arr[], unsigned char n)
{
    unsigned long sum = 0;
    unsigned char i;
    for (i = TRIM_COUNT; i < n - TRIM_COUNT; i++)
	{
        sum += arr[i];
    }
    return (unsigned char)(sum / (n - 2 * TRIM_COUNT));
}

void collect_samples()
{
    unsigned char values[SENSOR_COUNT];
    unsigned char all_done = 0;
    unsigned char i;

    OLED_Clear();
    OLED_ShowString(0,0,"Learning...", 16);

    while (!all_done)
	{
        read_all_sensors(values);
        
        for (i = 0; i < SENSOR_COUNT; i++)
		{

            if (values[i] > BLACK_THRESHOLD && sensors[i].sample_counts[0] < SAMPLE_SIZE)
			{
                sensors[i].black_samples[sensors[i].sample_counts[0]] = values[i];
                sensors[i].sample_counts[0]++;
            }

            if (values[i] < WHITE_THRESHOLD && sensors[i].sample_counts[1] < SAMPLE_SIZE) 
			{
                sensors[i].white_samples[sensors[i].sample_counts[1]] = values[i];
                sensors[i].sample_counts[1]++;
            }
        }

        all_done = 1;
        for (i = 0; i < SENSOR_COUNT; i++)
		{
            if (sensors[i].sample_counts[0] < SAMPLE_SIZE || sensors[i].sample_counts[1] < SAMPLE_SIZE)
			{
                all_done = 0;
                break;
            }
        }
    }
}

void calculate_thresholds()
{
    unsigned char i;
    for (i = 0; i < SENSOR_COUNT; i++)
	{

        insert_sort(sensors[i].black_samples, SAMPLE_SIZE);
        sensors[i].black_center = calculate_average(sensors[i].black_samples, SAMPLE_SIZE);
        sensors[i].black_min = (sensors[i].black_center > THRESHOLD_RANGE) ? 
                              (sensors[i].black_center - THRESHOLD_RANGE) : 0;
        sensors[i].black_max = (sensors[i].black_center + THRESHOLD_RANGE < 255) ? 
                              (sensors[i].black_center + THRESHOLD_RANGE) : 255;

        insert_sort(sensors[i].white_samples, SAMPLE_SIZE);
        sensors[i].white_center = calculate_average(sensors[i].white_samples, SAMPLE_SIZE);
        sensors[i].white_min = (sensors[i].white_center > THRESHOLD_RANGE) ? 
                              (sensors[i].white_center - THRESHOLD_RANGE) : 0;
        sensors[i].white_max = (sensors[i].white_center + THRESHOLD_RANGE < 255) ? 
                              (sensors[i].white_center + THRESHOLD_RANGE) : 255;
    }
    calibration_done = 1;

    OLED_Clear();
    OLED_ShowString(0, 0, "Calibration Done", 16);
    OLED_ShowString(0, 2, "BM:", 16);
    OLED_ShowNum(24, 2, sensors[0].black_center, 3, 16);
    OLED_ShowString( 64 , 2, "WM:", 16);
    OLED_ShowNum(88, 2, sensors[0].white_center, 3, 16);
	
	OLED_ShowString(0, 4, "BH:", 16);
    OLED_ShowNum(24, 4, sensors[0].black_max, 3, 16);
    OLED_ShowString(64, 4, "WH:", 16);
    OLED_ShowNum(88, 4, sensors[0].white_max, 3, 16);
	
	OLED_ShowString(0, 6, "BL:", 16);
    OLED_ShowNum(24, 6, sensors[0].black_min, 3, 16);
    OLED_ShowString(64, 6, "WL:", 16);
    OLED_ShowNum(88, 6, sensors[0].white_min, 3, 16);
}