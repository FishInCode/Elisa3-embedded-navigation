#ifndef __SelfLearning_H__
#define __SelfLearning_H__

void init_sensors();
void collect_samples();
void calculate_thresholds();
	
extern unsigned char idata MultiChannelAdcBuffer[9];
extern bit calibration_done;

#endif