#include "InfraredTrack.h"
#include "stc8a8kxxd4.h"

#define err 255

unsigned char bdata Track_bit = 0;

unsigned char idata Track_info[64] =
{
	  0,  8,  4,  6,  0,err,  3, 15,     //0~7
	  0,err,err,err,  0,err,  3, 15,     //8~15
	251,err,err,err,err,err,err,err,    //16~23
	252,err,err,err,  3,err,err,err,    //24~31
	247,err,err,err,err,err,err,err,    //32~39
	err,err,err,err,err,err,err,err,    //40~47
	249,err,err,err,err,err,err,err,    //48~55
	240,err,err,err,240,err,err,err     //56~63
};


sbit Track_bit0 = Track_bit ^ 0;
sbit Track_bit1 = Track_bit ^ 1;
sbit Track_bit2 = Track_bit ^ 2;
sbit Track_bit3 = Track_bit ^ 3;
sbit Track_bit4 = Track_bit ^ 4;
sbit Track_bit5 = Track_bit ^ 5;

unsigned char GetTrackInfo()
{
	Track_bit0 &= !(ADCdata[0] <= (ADCWhiteInfo[0]+8));
	Track_bit0 |=  (ADCdata[0] >= (ADCBlackInfo[0]-32));
	
	Track_bit1 &= !(ADCdata[1] <= (ADCWhiteInfo[1]+8));
	Track_bit1 |=  (ADCdata[1] >= (ADCBlackInfo[1]-32));

	Track_bit2 &= !(ADCdata[2] <= (ADCWhiteInfo[2]+8));
	Track_bit2 |=  (ADCdata[2] >= (ADCBlackInfo[2]-32));
	
	Track_bit3 &= !(ADCdata[3] <= (ADCWhiteInfo[3]+8));
	Track_bit3 |=  (ADCdata[3] >= (ADCBlackInfo[3]-32));
	
	Track_bit4 &= !(ADCdata[4] <= (ADCWhiteInfo[4]+8));
	Track_bit4 |=  (ADCdata[4] >= (ADCBlackInfo[4]-32));
	
	Track_bit5 &= !(ADCdata[5] <= (ADCWhiteInfo[5]+8));
	Track_bit5 |=  (ADCdata[5] >= (ADCBlackInfo[5]-32));
	
	return Track_bit;
}

void Track()
{
	Track_bit = GetTrackInfo();
	
	if(Track_info[Track_bit]==255){}
	else if(Track_info[Track_bit]==0){PulseWidthOfMotorA=InitSpeedA;PulseWidthOfMotorB=InitSpeedB;}
	else if(Track_info[Track_bit]<127){PulseWidthOfMotorA=(InitSpeedA+(  0+Track_info[Track_bit]));}
	else if(Track_info[Track_bit]>128){PulseWidthOfMotorB=(InitSpeedB+(255-Track_info[Track_bit]));}

}

void BlackInfo()
{
	ADCBlackInfo[0] = ADCdata[0];
	ADCBlackInfo[1] = ADCdata[1];
	ADCBlackInfo[2] = ADCdata[2];
	ADCBlackInfo[3] = ADCdata[3];
	ADCBlackInfo[4] = ADCdata[4];
	ADCBlackInfo[5] = ADCdata[5];
}

void WhiteInfo()
{
	ADCWhiteInfo[0] = ADCdata[0];
	ADCWhiteInfo[1] = ADCdata[1];
	ADCWhiteInfo[2] = ADCdata[2];
	ADCWhiteInfo[3] = ADCdata[3];
	ADCWhiteInfo[4] = ADCdata[4];
	ADCWhiteInfo[5] = ADCdata[5];
}