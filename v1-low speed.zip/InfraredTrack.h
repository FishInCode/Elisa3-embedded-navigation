#ifndef __TIMER_H__
#define __TIMER_H__

extern void Track();
extern unsigned char ADCBlackInfo[6],ADCWhiteInfo[6];
extern unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;
extern unsigned char InitSpeedA,InitSpeedB;
extern unsigned char data ADCdata[7];
#endif
