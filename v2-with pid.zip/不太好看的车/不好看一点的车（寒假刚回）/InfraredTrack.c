#include "InfraredTrack.h"
#include "stc8a8kxxd4.h"
#include "oled.h"

#define err 255
#define bal 0

unsigned int bdata Track_bit = 0;
unsigned char idata Track_info[64] =
{
	bal, 28, 22, 23,  3,err, 13, 27,     //0~7
	252,err,err, 12,bal,err, 16, 24,     //8~15
	233,err,err,err,err,err,err,err,    //16~23
	242,err,err,err,235,err,err, 15,    //24~31
	223,err,err,err,err,err,err,err,    //32~39
	err,err,err,err,err,err,err,err,    //40~47
	232,err,err,err,243,err,err,err,    //48~55
	228,err,err,err,226,err,240,bal     //56~63
};
//unsigned char idata Track_info[64] =
//{
//	bal,err,err,err,  2,err,  9,err,     //0~7
//	253,err,err,err,bal,err,err,err,     //8~15
//	err,err,err,err,err,err,err,err,    //16~23
//	246,err,err,err,err,err,err,err,    //24~31
//	err,err,err,err,err,err,err,err,    //32~39
//	err,err,err,err,err,err,err,err,    //40~47
//	err,err,err,err,err,err,err,err,    //48~55
//	err,err,err,err,err,err,err,bal     //56~63
//};


//unsigned char idata Track_info[64] =
//{
//	bal, 33, 25, 30,  2,err,  4, 27,     //0~7
//	253,err,err, 12,bal,err, 16, 24,     //8~15
//	230,err,err,err,err,err,err,err,    //16~23
//	251,err,err,err,235,err,err, 15,    //24~31
//	222,err,err,err,err,err,err,err,    //32~39
//	err,err,err,err,err,err,err,err,    //40~47
//	225,err,err,err,243,err,err,err,    //48~55
//	228,err,err,err,226,err,240,bal     //56~63
//};

sbit Track_bit0 = Track_bit ^ 0;
sbit Track_bit1 = Track_bit ^ 1;
sbit Track_bit2 = Track_bit ^ 2;
sbit Track_bit3 = Track_bit ^ 3;
sbit Track_bit4 = Track_bit ^ 4;
sbit Track_bit5 = Track_bit ^ 5;
sbit Track_bit6 = Track_bit ^ 6;
sbit Track_bit7 = Track_bit ^ 7;
sbit Track_bit8 = Track_bit ^ 8;

unsigned int GetTrackInfo()
{
	Track_bit0 &= !(MultiChannelAdcBuffer[0] <= (ADCWhiteInfo[0]+8));
	Track_bit0 |=  (MultiChannelAdcBuffer[0] >= (ADCBlackInfo[0]-32));
	
	Track_bit1 &= !(MultiChannelAdcBuffer[1] <= (ADCWhiteInfo[1]+8));
	Track_bit1 |=  (MultiChannelAdcBuffer[1] >= (ADCBlackInfo[1]-32));

	Track_bit2 &= !(MultiChannelAdcBuffer[2] <= (ADCWhiteInfo[2]+8));
	Track_bit2 |=  (MultiChannelAdcBuffer[2] >= (ADCBlackInfo[2]-32));
	
	Track_bit3 &= !(MultiChannelAdcBuffer[3] <= (ADCWhiteInfo[3]+8));
	Track_bit3 |=  (MultiChannelAdcBuffer[3] >= (ADCBlackInfo[3]-32));
	
	Track_bit4 &= !(MultiChannelAdcBuffer[4] <= (ADCWhiteInfo[4]+8));
	Track_bit4 |=  (MultiChannelAdcBuffer[4] >= (ADCBlackInfo[4]-32));
	
	Track_bit5 &= !(MultiChannelAdcBuffer[5] <= (ADCWhiteInfo[5]+8));
	Track_bit5 |=  (MultiChannelAdcBuffer[5] >= (ADCBlackInfo[5]-32));
	
	Track_bit6 &= !(MultiChannelAdcBuffer[6] <= (ADCWhiteInfo[6]+8));
	Track_bit6 |=  (MultiChannelAdcBuffer[6] >= (ADCBlackInfo[6]-32));
	
	Track_bit7 &= !(MultiChannelAdcBuffer[7] <= (ADCWhiteInfo[5]+8));
	Track_bit7 |=  (MultiChannelAdcBuffer[7] >= (ADCBlackInfo[5]-32));
	
	Track_bit8 &= !(MultiChannelAdcBuffer[8] <= (ADCWhiteInfo[8]+8));
	Track_bit8 |=  (MultiChannelAdcBuffer[8] >= (ADCBlackInfo[8]-32));
	
	return Track_bit;
}

void Track()
{
	Track_bit = GetTrackInfo();
//	PulseWidthOfMotorA =((Track_info[Track_bit] == err) * (PulseWidthOfMotorA) 
//					   + (Track_info[Track_bit] == bal) * (InitSpeedA) 
//					   + (Track_info[Track_bit] > bal && Track_info[Track_bit] < 127) * (InitSpeedA+(  0+Track_info[Track_bit])));
//	PulseWidthOfMotorB =((Track_info[Track_bit] == err) * (PulseWidthOfMotorB) 
//					   + (Track_info[Track_bit] == bal) * (InitSpeedB) 
//					   + (Track_info[Track_bit] < err && Track_info[Track_bit] > 128) * (InitSpeedB+(255-Track_info[Track_bit])));
	
	if(Track_info[Track_bit]==255){}
	else if(Track_info[Track_bit]==0){PulseWidthOfMotorA=InitSpeedA;PulseWidthOfMotorB=InitSpeedB;}
	else if(Track_info[Track_bit]<127){PulseWidthOfMotorA=(InitSpeedA+(  0+Track_info[Track_bit]));}
	else if(Track_info[Track_bit]>128){PulseWidthOfMotorB=(InitSpeedB+(255-Track_info[Track_bit]));}

}

void SHOWDKK()
{
	OLED_ShowNum(56,2,Track_bit8,1,16);
	OLED_ShowNum(64,2,Track_bit7,1,16);
	OLED_ShowNum(72,2,Track_bit6,1,16);
	OLED_ShowNum(80,2,Track_bit5,1,16);
	OLED_ShowNum(88,2,Track_bit4,1,16);
	OLED_ShowNum(96,2,Track_bit3,1,16);
	OLED_ShowNum(104,2,Track_bit2,1,16);
	OLED_ShowNum(112,2,Track_bit1,1,16);
	OLED_ShowNum(120,2,Track_bit0,1,16);
}

void BlackInfo()
{
	ADCBlackInfo[0] = MultiChannelAdcBuffer[0];
	ADCBlackInfo[1] = MultiChannelAdcBuffer[1];
	ADCBlackInfo[2] = MultiChannelAdcBuffer[2];
	ADCBlackInfo[3] = MultiChannelAdcBuffer[3];
	ADCBlackInfo[4] = MultiChannelAdcBuffer[4];
	ADCBlackInfo[5] = MultiChannelAdcBuffer[5];
	ADCBlackInfo[6] = MultiChannelAdcBuffer[6];
	ADCBlackInfo[7] = MultiChannelAdcBuffer[7];
	ADCBlackInfo[8] = MultiChannelAdcBuffer[8];
}

void WhiteInfo()
{
	ADCWhiteInfo[0] = MultiChannelAdcBuffer[0];
	ADCWhiteInfo[1] = MultiChannelAdcBuffer[1];
	ADCWhiteInfo[2] = MultiChannelAdcBuffer[2];
	ADCWhiteInfo[3] = MultiChannelAdcBuffer[3];
	ADCWhiteInfo[4] = MultiChannelAdcBuffer[4];
	ADCWhiteInfo[5] = MultiChannelAdcBuffer[5];
	ADCWhiteInfo[6] = MultiChannelAdcBuffer[6];
	ADCWhiteInfo[7] = MultiChannelAdcBuffer[7];
	ADCWhiteInfo[8] = MultiChannelAdcBuffer[8];
}