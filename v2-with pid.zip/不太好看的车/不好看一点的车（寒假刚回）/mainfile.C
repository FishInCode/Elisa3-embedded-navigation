#include "ADC_stc8a8k64d4.h"
#include "stc8a8kxxd4.h"
#include "oled.h"
#include <intrins.h>
#include "timer.h"
#include "InfraredTrack.h"

#define  uchar unsigned char
#define  uint unsigned int

extern void Track();
extern void SHOWDKK();
extern unsigned int GetTrackInfo();
extern void BlackInfo();
extern void WhiteInfo();
unsigned char ADCBlackInfo[9] = {200,200,200,200,200,200,200,200};
unsigned char ADCWhiteInfo[9] = {8,8,8,8,8,8,8,8};
unsigned char InitSpeedA,InitSpeedB;
//unsigned int data SingleChannelAdcBuffer[8];
unsigned char data MultiChannelAdcChannelNumber;
unsigned char idata MultiChannelAdcBuffer[9];
unsigned char data Timer0Count;

unsigned char idata MotorAfunction,MotorBfunction,MotorCfunction;
/*  Motor x function=0:��ת       */
/*  Motor x function=1:��ת       */
/*  Motor x function=2:��Ȼֹͣ   */
/*  Motor x function=3:ɲͣ       */

unsigned char idata PulseWidthOfMotorA,PulseWidthOfMotorB,PulseWidthOfMotorC;

//extern uchar code MotorFunctionLabels[4] = {'D','R','S','J'};
//extern uchar code MotorLabels[3] = {'a','b','c'};	//������motor  a/b/c


unsigned char bdata Flag;
sbit F1keyShortPress 	= Flag ^ 0;
sbit F1keyLongPress 	= Flag ^ 1;
sbit F2keyShortPress	= Flag ^ 2;
sbit F2keyLongPress		= Flag ^ 3;
sbit F3keyShortPress	= Flag ^ 4;
sbit F3keyLongPress		= Flag ^ 5;
sbit F4keyShortPress	= Flag ^ 6;
sbit F4keyLongPress		= Flag ^ 7;

unsigned char idata F1KeyCnt,F2KeyCnt,F3KeyCnt,F4KeyCnt;

unsigned char idata FlagOf10ms;

unsigned int Length(unsigned char Speed)
{
	if(Speed < 10) {return 1;}
	else if(Speed >= 100) {return 3;}
	else {return 2;}
}

void DelayMs( unsigned int delay_time )
	{
	unsigned int delay_cnt;
	while(delay_time--)
       {
       for(delay_cnt=0;delay_cnt<200;delay_cnt++)
			{
            _nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
			_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
			_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();_nop_();
            }
       _nop_();
       }
	_nop_();
	}
	
void IOiniitial_stc8a8k64D4(void)
	{
/*--------I/O port setup-----*/
/*  PxM1  PxM0      MODEl    */
/*    0     0     ׼˫���   */
/*    0     1     ǿ������� */
/*    1     0     ��������   */
/*    1     1     ��©���   */
/*---------------------------*/		
		
//	P7M1 = 0x00;P7M0 = 0x00; /*P7 ׼˫���*/
//	P6M1 = 0x00;P6M0 = 0x00; /*P6 ׼˫���*/
	P5M1 = 0x00; 	//0b0000,0000	//P5.4/P5.5:׼˫���,����OLED��
	P5M0 = 0x00; 	//0b0000,0000		
	P4M1 = 0x00; 	//0b0000,0000	//P4.0:׼˫���,KEY2
	P4M0 = 0x1e;	//0b0001,1110	//P4.1-P4.4:ǿ�������(�������)
	P3M1 = 0x00; 	//0b0000,0000	//P3.6/P3.7:ǿ�������(�������)
	P3M0 = 0xc0;	//0b1100,0000	//P3.0/P3.4/P3.5:׼˫���,KEY1/KEY3/KEY4
									//P3.3-P3.2:׼˫���
	P2M1 = 0x38;	//0b0011,1000	//P2.0-P2.2,P2.6/P2.7:ǿ�������(�������ֶ��)
	P2M0 = 0xc7;	//0b1100,0111	//P2.3/P2.4/P2.5:�����(CCP0-2)
	P1M1 = 0x80;P1M0 = 0x00; 	//P1.7:ADC����,P1.0-P1.6:׼˫���*/
	P0M1 = 0x00;P0M0 = 0x00; 	//׼˫���
	
//	 P_SW2 |= 0x80;			  	//ʹ����չSFR

/*  P0.1,P0.3:ʹ�ܶ˿��ڲ�4.1k��������,P0.1/P0.3��TxD3/TxD4*/
//	P0PU = 0x0a;	//0b0000,1010,
/*  P1.3,P1.5:ʹ�ܶ˿��ڲ�4.1k��������,��ǿLED����*/
//	P1PU = 0x28;	//0b00101000
/*  P2.7,P2.5,P2.4:ʹ�ܶ˿��ڲ�4.1k��������,P2.7��ǿLED����,P2.5,P2.4����I2C���ߵ���������*/
//	P2PU = 0xb0;	//0b10110000
/*  P4.4:ʹ�ܶ˿��ڲ�4.1k��������,��ǿLED����*/
//	P4PU = 0x10;	//0b10110000

//	P_SW2	&= ~0x80;	//ֹͣ"ʹ����չSFR"

	}

void main(void)
{
		
	uchar data Turntime = 0;
	uchar data Count4 = 1;
	uchar data wbp = 0;
	
	uchar idata UserCnt = 0;
	uchar idata charReg = 0;
	uchar idata UserReg = 0;
	uint idata intReg = 100;
	
	DelayMs( 100 );
	PulseWidthOfMotorA=0;PulseWidthOfMotorB=0;PulseWidthOfMotorC=0;
	InitSpeedA = PulseWidthOfMotorA;InitSpeedB = PulseWidthOfMotorB;
	initADCinMultiChannel();
	IOiniitial_stc8a8k64D4();
	initialTimer0_4();	
	OLED_Init();
	
	
	_nop_();
	EA = 1;		//���ж�����	
	
//	OLED_ShowString(0,0,"funcA:",16);OLED_ShowNum(48,0,MotorAfunction,1,16);
//	OLED_ShowArrow(40,0,0);
//	OLED_ShowString(0,2,"funcB:",16);OLED_ShowNum(48,2,MotorBfunction,1,16);
//	OLED_ShowString(0,4,"pwmA:",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
//	OLED_ShowString(0,6,"pwmB:",16);OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);
	
//	OLED_ShowString(64,6,"Bt:",16);
//	OLED_ShowString(120,6,"V",16);
	
	while( 1 )
	{
		_nop_();
		
//		OLED_ShowNum(64,6,GetTrackInfo(),5,16);
//		SHOWDKK();
//		OLED_ShowFloatNum(88,6,ADCdata[6]*0.05859375,2,16);
		
		OLED_ShowNum(64,0,MultiChannelAdcBuffer[0],3,16);
		OLED_ShowNum(64,2,MultiChannelAdcBuffer[1],3,16);
		OLED_ShowNum(64,4,MultiChannelAdcBuffer[2],3,16);
		OLED_ShowNum(64,6,MultiChannelAdcBuffer[3],3,16);
		OLED_ShowNum(96,0,MultiChannelAdcBuffer[4],3,16);
		OLED_ShowNum(96,2,MultiChannelAdcBuffer[5],3,16);
		OLED_ShowNum(96,4,MultiChannelAdcBuffer[6],3,16);
		OLED_ShowNum(96,6,MultiChannelAdcBuffer[7],3,16);
		OLED_ShowNum(0,0,MultiChannelAdcBuffer[8],3,16);
		if(F1keyShortPress == 1)
		{
			_nop_();
			F1keyShortPress = 0;
			
			switch(Count4)
			{
				
				case 1: MotorAfunction = 0;OLED_ShowNum(48,0,MotorAfunction,1,16);break;
				case 2: MotorBfunction = 0;OLED_ShowNum(48,2,MotorBfunction,1,16);break;

				case 3: 
						InitSpeedA += 1;PulseWidthOfMotorA = InitSpeedA;
						OLED_ShowString(40,4,"   ",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);break;
				case 4: 
						InitSpeedB += 1;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,6,"   ",16);	OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				
				case 5: MotorAfunction = 0;MotorBfunction = 0;
						OLED_ShowNum(48,0,MotorAfunction,1,16);OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				case 6: 
						InitSpeedA += 1;PulseWidthOfMotorA = InitSpeedA;
						InitSpeedB += 1;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,4,"   ",16);OLED_ShowString(40,6,"   ",16);
						OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
						OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				case 7: OLED_ShowString(64,0,"GetBlack",16);
						while( 1 )
						{
							BlackInfo();
							if(F1keyShortPress == 1)
							{
								F1keyShortPress =0;
								_nop_();
								break;
							}
						}
						OLED_ShowString(64,0,"        ",16);
						
				default:break;
			}
		}
		if(F1keyLongPress == 1)
		{
			F1keyLongPress =0;
			_nop_();
				
			switch(Count4)
			{
				
				case 1: MotorAfunction = 2;OLED_ShowNum(48,0,MotorAfunction,1,16);break;
				case 2: MotorBfunction = 2;OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				
				case 3: 
						InitSpeedA += 16;PulseWidthOfMotorA = InitSpeedA;
						OLED_ShowString(40,4,"   ",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);break;
				case 4: 
						InitSpeedB += 16;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,6,"   ",16);	OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				case 5: MotorAfunction = 2;MotorBfunction = 2;
						OLED_ShowNum(48,0,MotorAfunction,1,16);OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				case 6: 
						InitSpeedA += 16;PulseWidthOfMotorA = InitSpeedA;
						InitSpeedB += 16;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,4,"   ",16);OLED_ShowString(40,6,"   ",16);
						OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
						OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				default:break;
			}
		}
			
		if(F2keyShortPress == 1)
		{
			F2keyShortPress =0;
			_nop_();
			OLED_ShowString(64,0,"Tracking",16);
			while( 1 )
			{
				Track();
				//DelayMs( 1 );
				if(F2keyShortPress == 1)
				{
					F2keyShortPress =0;
					_nop_();
					break;
				}
			}
			PulseWidthOfMotorA = InitSpeedA;
			PulseWidthOfMotorB = InitSpeedB;
			OLED_ShowString(64,0,"        ",16);
		}
		if(F2keyLongPress == 1)
		{
			F2keyLongPress =0;
			_nop_();
			OLED_Clear();
			OLED_ShowString(0,0,"Brake",16);
			MotorAfunction = 3;	
			MotorBfunction = 3;
		}
		
		if(F3keyShortPress == 1)	
		{
			F3keyShortPress =0;
			_nop_();
		
			switch(Count4)
			{
				
				case 1: MotorAfunction = 1;OLED_ShowNum(48,0,MotorAfunction,1,16);break;
				case 2: MotorBfunction = 1;OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				case 3: 
						InitSpeedA -= 1;PulseWidthOfMotorA = InitSpeedA;
						OLED_ShowString(40,4,"   ",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);break;
				case 4: 
						InitSpeedB -= 1;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,6,"   ",16);	OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				case 5: MotorAfunction = 1;MotorBfunction = 1;
						OLED_ShowNum(48,0,MotorAfunction,1,16);OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				case 6: 
						InitSpeedA -= 1;PulseWidthOfMotorA = InitSpeedA;
						InitSpeedB -= 1;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,4,"   ",16);OLED_ShowString(40,6,"   ",16);
						OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
						OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				
				case 7: OLED_ShowString(64,0,"GetWhite",16);
						while( 1 )
						{
							WhiteInfo();
							if(F3keyShortPress == 1)
							{
								F3keyShortPress =0;
								_nop_();
								break;
							}
						}
						OLED_ShowString(64,0,"        ",16);
						
				default:break;
			}
		}
		if(F3keyLongPress == 1)		
		{
			F3keyLongPress =0;
			_nop_();
			switch(Count4)
			{
				
				case 1: MotorAfunction = 3;OLED_ShowNum(48,0,MotorAfunction,1,16);break;
				case 2: MotorBfunction = 3;OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				
				case 3: 
						InitSpeedA -= 16;PulseWidthOfMotorA = InitSpeedA;
						OLED_ShowString(40,4,"   ",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);break;
				case 4: 
						InitSpeedB -= 16;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,6,"   ",16);	OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				case 5: MotorAfunction = 3;MotorBfunction = 3;
						OLED_ShowNum(48,0,MotorAfunction,1,16);OLED_ShowNum(48,2,MotorBfunction,1,16);break;
				case 6: 
						InitSpeedA -= 16;PulseWidthOfMotorA = InitSpeedA;
						InitSpeedB -= 16;PulseWidthOfMotorB = InitSpeedB;
						OLED_ShowString(40,4,"   ",16);OLED_ShowString(40,6,"   ",16);
						OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
						OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);break;
				default:break;
			}
		}
		
		if(F4keyShortPress == 1)	
		{
			F4keyShortPress =0;
			_nop_();
			switch(Count4)
			{
				case 1:OLED_ShowChar(40,0,':',16);break;
				case 2:OLED_ShowChar(40,2,':',16);break;
				case 3:OLED_ShowChar(32,4,':',16);break;
				case 4:OLED_ShowChar(32,6,':',16);break;
				case 5:OLED_ShowChar(40,0,':',16); OLED_ShowChar(40,2,':',16);break;
				case 6:OLED_ShowChar(32,4,':',16); OLED_ShowChar(32,6,':',16);break;
				default:break;
			}
			Count4++;
			if(Count4 > 7) Count4 = 1;
			switch(Count4)
			{
				case 1:{OLED_ShowArrow(40,0,0);}break;
				case 2:{OLED_ShowArrow(40,2,0);}break;
				case 3:{OLED_ShowArrow(32,4,0);}break;
				case 4:{OLED_ShowArrow(32,6,0);}break;
				case 5:{OLED_ShowArrow(40,0,0); OLED_ShowArrow(40,2,0);}break;
				case 6:{OLED_ShowArrow(32,4,0); OLED_ShowArrow(32,6,0);}break;
				default:break;
			}  
		}
		if(F4keyLongPress == 1)
		{
			F4keyLongPress =0;
			_nop_();
			OLED_Clear();
			OLED_ShowNum(0,0,ADCBlackInfo[5],3,16);
			OLED_ShowNum(40,0,ADCBlackInfo[4],3,16);
			OLED_ShowNum(80,0,ADCBlackInfo[3],3,16);
			OLED_ShowNum(0,2,ADCBlackInfo[2],3,16);
			OLED_ShowNum(40,2,ADCBlackInfo[1],3,16);
			OLED_ShowNum(80,2,ADCBlackInfo[0],3,16);
			OLED_ShowNum(0,4,ADCWhiteInfo[5],3,16);
			OLED_ShowNum(40,4,ADCWhiteInfo[4],3,16);
			OLED_ShowNum(80,4,ADCWhiteInfo[3],3,16);
			OLED_ShowNum(0,6,ADCWhiteInfo[2],3,16);
			OLED_ShowNum(40,6,ADCWhiteInfo[1],3,16);
			OLED_ShowNum(80,6,ADCWhiteInfo[0],3,16);
			
			DelayMs( 3000 );
			OLED_Clear();
	
			OLED_ShowString(0,0,"funcA:",16);OLED_ShowNum(48,0,MotorAfunction,1,16);
			OLED_ShowString(0,2,"funcB:",16);OLED_ShowNum(48,2,MotorBfunction,1,16);
			OLED_ShowString(0,4,"pwmA:",16);OLED_ShowNum(40,4,PulseWidthOfMotorA,Length(PulseWidthOfMotorA),16);
			OLED_ShowString(0,6,"pwmB:",16);OLED_ShowNum(40,6,PulseWidthOfMotorB,Length(PulseWidthOfMotorB),16);
			OLED_ShowString(64,6,"Bt:",16);
			OLED_ShowString(120,6,"V",16);
			
		}
	}
}
